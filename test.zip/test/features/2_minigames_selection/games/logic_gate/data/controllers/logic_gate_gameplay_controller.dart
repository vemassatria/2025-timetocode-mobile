import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:timetocode/app/config/routes/app_route.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/data/controllers/logic_gate_websocket_controller.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/data/models/binary_slot_model.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/data/models/card_slot_model.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/data/models/logic_gate_card_model.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/data/models/logic_gate_type.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/data/models/player_model.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/data/services/ai_service.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/data/states/ai_game_state.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/data/states/logic_gate_state.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/data/states/logic_gate_websocket_state.dart';

final logicGateControllerProvider =
    NotifierProvider.autoDispose<LogicGateGameplayController, LogicGateState>(
      LogicGateGameplayController.new,
    );

class LogicGateGameplayController extends AutoDisposeNotifier<LogicGateState> {
  KeepAliveLink? _keepAliveLink;
  AiService? _aiService;
  VoidCallback? _updateLineConnection;

  @override
  LogicGateState build() {
    ref.onDispose(() {
      _aiService?.dispose();
    });
    return const LogicGateState();
  }

  void initializeLogicGateGame({
    bool isVsAI = false,
    bool isOnline = false,
    AiDifficulty difficulty = AiDifficulty.medium,
  }) async {
    _keepAliveLink ??= ref.keepAlive();

    if (isVsAI) {
      _aiService = AiService();
      await _aiService!.loadModel();
    }

    state = LogicGateState(
      binarySlots: _initializeBinarySlots(15),
      cardSlots: _initializeCardSlots(10),
      player: PlayerModel(id: 1, hand: _getAvailableCards(1), targetValue: 1),
      opponent: PlayerModel(id: 0, hand: _getAvailableCards(2), targetValue: 0),
      vsAI: isVsAI,
      isOnline: isOnline,
      difficulty: difficulty,
    );

    if (isOnline) {
      ref.listen<LogicGateWebsocketState>(
        logicGateWebsocketControllerProvider,
        (previous, next) {
          if (next.gameState != null && next.gameState != previous?.gameState) {
            state = next.gameState!.copyWith(isOnline: true);
          }
        },
      );
      final initialWebsocketState = ref.read(
        logicGateWebsocketControllerProvider,
      );
      if (initialWebsocketState.gameState != null) {
        state = initialWebsocketState.gameState!.copyWith(isOnline: true);
      }
    }
  }

  void updateLineConnection(VoidCallback callback) {
    _updateLineConnection = callback;
  }

  List<LogicGateCardModel> _getAvailableCards(int playerId) {
    const int numberOfCards = 5;
    const availableTypes = LogicGateType.values;

    final int startId = (playerId == 1) ? 1 : (numberOfCards + 1);

    return List.generate(numberOfCards, (index) {
      return LogicGateCardModel(
        id: startId + index,
        type: availableTypes[index],
      );
    });
  }

  List<CardSlotModel> _initializeCardSlots(int count) {
    return List.generate(count, (index) {
      return CardSlotModel(id: index + 1);
    });
  }

  List<BinarySlotModel> _initializeBinarySlots(int count) {
    return List.generate(count, (index) {
      if (index < 5) {
        return BinarySlotModel(id: index + 1, value: index % 2);
      }
      return BinarySlotModel(id: index + 1);
    });
  }

  void dropCard(int slotId, int cardId) {
    if (state.isOnline) {
      ref
          .read(logicGateWebsocketControllerProvider.notifier)
          .sendPlayerMove(slotId, cardId);
      return;
    }

    final isPlayerTurn = state.currentPlayerId == 1;
    final user = isPlayerTurn ? state.player! : state.opponent!;
    final binarySlot = state.binarySlots!;
    /*
      Logic for removing card from user's hand
    */
    final cardToMove = user.hand.firstWhere((c) => c.id == cardId);
    final newHand = user.hand.where((c) => c.id != cardId).toList();
    final updatedUser = user.copyWith(hand: newHand);
    /*
      Logic for updating card slots
    */
    final newCardSlots = state.cardSlots!.map((slot) {
      if (slot.id == slotId) {
        return slot.copyWith(placedCard: cardToMove);
      }
      return slot;
    }).toList();
    /*
      Logic for calculating binary slot values based on card placement
    */
    final inputSlotId1 = calculateTopBinarySlotIndex(slotId);
    final inputSlotId2 = inputSlotId1 + 1;

    final value1 = binarySlot
        .firstWhere((slot) => slot.id == inputSlotId1)
        .value!;
    final value2 = binarySlot
        .firstWhere((slot) => slot.id == inputSlotId2)
        .value!;

    final outputSlotId = calculateNextBinarySlotIndex(
      inputSlotId1,
      inputSlotId2,
    );

    final resultValue = cardToMove.type.calculate(value1, value2);

    final newBinarySlot = binarySlot.map((slot) {
      if (slot.id == outputSlotId) {
        return slot.copyWith(value: resultValue);
      }
      return slot;
    }).toList();

    final nextPlayerId = isPlayerTurn ? 0 : 1;

    state = slotId == 10
        ? state.copyWith(
            cardSlots: newCardSlots,
            binarySlots: newBinarySlot,
            player: isPlayerTurn ? updatedUser : state.player,
            opponent: !isPlayerTurn ? updatedUser : state.opponent,
            lastUpdatedCardSlotId: slotId,
            winnerPlayerId: resultValue == 1 ? 1 : 2,
          )
        : state.copyWith(
            cardSlots: newCardSlots,
            binarySlots: newBinarySlot,
            player: isPlayerTurn ? updatedUser : state.player,
            opponent: !isPlayerTurn ? updatedUser : state.opponent,
            currentPlayerId: nextPlayerId,
            lastUpdatedCardSlotId: slotId,
          );

    if (state.vsAI && nextPlayerId == 0) {
      _handleAiTurn();
    }
  }

  void _handleAiTurn() {
    final aiGameState = AiGameState(
      binarySlots: state.binarySlots!,
      cardSlots: state.cardSlots!,
      player1Hand: state.player!.hand,
      player2Hand: state.opponent!.hand,
      currentPlayerId: 0,
    );

    final move = _aiService!.predictMove(
      gameState: aiGameState,
      difficulty: state.difficulty,
    );

    if (move != null) {
      final slotId = move['slot']!;
      final cardTypeId = move['card']!;

      final cardInHand = state.opponent!.hand.firstWhere(
        (card) => card.type.index + 1 == cardTypeId,
      );

      dropCard(slotId, cardInHand.id);
    }
  }

  // find next binary slot index based on the previous binary slots
  int calculateNextBinarySlotIndex(int x, int y) {
    final offset = (x - 1) ~/ 4;
    const int fixedOffset = 4;

    return y + fixedOffset - offset;
  }

  // calculate binary slot index (on the top position) based on the card slot index
  int calculateTopBinarySlotIndex(int x) {
    bool isLowerThanEight = x < 8;
    final offset = isLowerThanEight ? (x - 1) ~/ 4 : (x - 1) ~/ 3;
    return x + offset;
  }

  void _releaseKeepAlive() {
    _keepAliveLink!.close();
    _keepAliveLink = null;
  }

  void exit() {
    if (state.isOnline) {
      ref.read(logicGateWebsocketControllerProvider.notifier).leaveRoom();
    }
    _releaseKeepAlive();
    ref.read(routerProvider).pop();
  }

  void restart() {
    _updateLineConnection!();
    initializeLogicGateGame(isVsAI: state.vsAI, difficulty: state.difficulty);
  }
}
