import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:go_router/go_router.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:timetocode/app/config/theme/colors.dart';
import 'package:timetocode/app/config/theme/typography.dart';
import 'package:timetocode/app/data/services/sound_effect_service.dart';
import 'package:timetocode/app/utils/overlay_utils.dart';
import 'package:timetocode/app/widgets/buttons/bordered_button.dart';
import 'package:timetocode/app/widgets/buttons/custom_button.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/data/controllers/logic_gate_gameplay_controller.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/data/models/logic_gate_type.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/data/providers/internet_status.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/presentation/widgets/ai_difficulty_popup.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/presentation/widgets/card_detail_carousel_popup.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/presentation/widgets/how_to_play_popup.dart';
import 'package:timetocode/features/2_minigames_selection/games/logic_gate/presentation/widgets/online_room_popup.dart';

class LogicGatePage extends ConsumerWidget {
  const LogicGatePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            ref.read(soundEffectServiceProvider.notifier).playButtonClick1();
            if (GoRouter.of(context).canPop()) {
              context.pop();
            } else {
              context.go('/minigames');
            }
          },
        ),
        centerTitle: true,
        title: Text(
          'Gerbang Logika',
          style: AppTypography.heading6(color: AppColors.white),
        ),
      ),
      body: Stack(
        children: [
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SvgPicture.asset(
              'assets/images/logic_gate/screen/upper_background.svg',
              fit: BoxFit.cover,
              height: 240.h,
              alignment: Alignment.topCenter,
            ),
          ),
          Padding(
            padding: EdgeInsets.all(24.w),
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.all(18.w),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceDark,
                    borderRadius: BorderRadius.circular(16.r),
                    border: Border.all(color: AppColors.white, width: 2.w),
                  ),
                  height: 250.h,
                  width: 264.w,
                  child: Text(
                    'Ini adalah permainan strategi di mana kamu dan lawan bergantian memasang kartu gerbang logika (AND, OR, NAND, NOR, XOR) untuk mengubah-ubah deretan angka 0 dan 1. Setiap pemain punya target angka akhir yang berbeda, yang akan ditentukan di awal permainan. Raih targetmu dan kalahkan lawan!',
                    style: AppTypography.smallNormalBold(
                      color: AppColors.white,
                    ),
                  ),
                ),
                SizedBox(height: 64.h),
                CustomButton(
                  icon: SvgPicture.asset(
                    'assets/images/logic_gate/icons/ai.svg',
                    width: 26.w,
                    height: 26.h,
                  ),
                  type: ButtonType.iconLabel,
                  label: "Mainkan Lawan AI",
                  onPressed: () =>
                      showPopupOverlay(context, const DifficultyPopup(), ref),
                  widthMode: ButtonWidthMode.fill,
                  color: ButtonColor.blue,
                ),
                SizedBox(height: 16.h),
                CustomButton(
                  icon: Icon(Icons.style, size: 26.r),
                  type: ButtonType.iconLabel,
                  label: "Mainkan Langsung",
                  onPressed: () {
                    ref
                        .read(logicGateControllerProvider.notifier)
                        .initializeLogicGateGame();
                    context.go('/minigames/logic-gate/gameplay');
                  },
                  widthMode: ButtonWidthMode.fill,
                  color: ButtonColor.purple,
                ),
                SizedBox(height: 16.h),
                CustomButton(
                  icon: SvgPicture.asset(
                    'assets/images/logic_gate/icons/peoples.svg',
                    width: 26.w,
                    height: 26.h,
                  ),
                  type: ButtonType.iconLabel,
                  label: "Mainkan Online",
                  onPressed: () =>
                      showPopupOverlay(context, const OnlineRoomPopup(), ref),
                  widthMode: ButtonWidthMode.fill,
                  color: ButtonColor.purple,
                  isDisabled:
                      ref.read(internetStatusProvider).hasValue &&
                      ref.read(internetStatusProvider).value ==
                          InternetConnectionStatus.disconnected,
                ),
                SizedBox(height: 16.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    BorderedButton(
                      icon: SvgPicture.asset(
                        'assets/images/logic_gate/icons/question.svg',
                        width: 24.w,
                        height: 24.h,
                      ),
                      type: BorderedButtonType.iconLabel,
                      label: "Cara Bermain",
                      onPressed: () {
                        showPopupOverlay(context, const HowToPlayPopup(), ref);
                      },
                      color: BorderedButtonColor.transparent,
                    ),
                    SizedBox(width: 8.w),
                    BorderedButton(
                      icon: SvgPicture.asset(
                        'assets/images/logic_gate/icons/cards.svg',
                        width: 24.w,
                        height: 24.h,
                      ),
                      type: BorderedButtonType.iconLabel,
                      label: "Detail Kartu",
                      onPressed: () {
                        showPopupOverlay(
                          context,
                          const CardDetailCarouselPopup(
                            types: LogicGateType.values,
                          ),
                          ref,
                        );
                      },
                      color: BorderedButtonColor.transparent,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
