// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'question_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_QuestionModel _$QuestionModelFromJson(Map<String, dynamic> json) =>
    _QuestionModel(
      id: json['id'] as String,
      conditions: (json['conditions'] as Map<String, dynamic>?)?.map(
        (k, e) => MapEntry(k, e as String),
      ),
      text: json['text'] as String,
      code: json['code'] as String?,
      choices: (json['choices'] as List<dynamic>)
          .map((e) => ChoicesModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      consequences: (json['consequences'] as Map<String, dynamic>?)?.map(
        (k, e) => MapEntry(k, e as String),
      ),
    );

Map<String, dynamic> _$QuestionModelToJson(_QuestionModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'conditions': instance.conditions,
      'text': instance.text,
      'code': instance.code,
      'choices': instance.choices,
      'consequences': instance.consequences,
    };
