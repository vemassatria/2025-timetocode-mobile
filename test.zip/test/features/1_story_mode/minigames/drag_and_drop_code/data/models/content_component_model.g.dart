// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'content_component_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_ContentComponentModel _$ContentComponentModelFromJson(
  Map<String, dynamic> json,
) => _ContentComponentModel(
  type: json['type'] as String,
  value: json['value'] as String,
);

Map<String, dynamic> _$ContentComponentModelToJson(
  _ContentComponentModel instance,
) => <String, dynamic>{'type': instance.type, 'value': instance.value};
